declare var i: any;
declare var s: any;
declare var t: {};
export { i as Terminal, s as __esModule, t as default };
