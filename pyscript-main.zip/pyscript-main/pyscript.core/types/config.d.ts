export default configs;
declare const configs: Map<any, any>;
